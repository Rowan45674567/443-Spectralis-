#include "ht16k33_bargraph.h"
#include <csignal>
#include <iostream>
#include <thread>
#include <chrono>
#include <atomic>

std::atomic<bool> running(true);

void signalHandler(int signum) {
  running = false;
}

int main() {
  BarGraph24 bar;
  if (!bar.begin()) {
    std::cerr << "Failed to initialize HT16K33\n";
    return 1;
  }

  // Set up signal handling to exit on Ctrl+C
  signal(SIGINT, signalHandler);

  // Define bar states using int array
  int ledStates[24];

  // Example: pattern - alternate red/green
  for (int i = 0; i < 24; ++i) {
    ledStates[i] = (i % 2 == 0) ? 1 : 2;  // RED for even, GREEN for odd
  }

  // Continuously update display until interrupted
  while (running) {
    bar.updateDisplay(ledStates, 24);
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
  }

  // On exit, clear display
  bar.clear();
  bar.writeDisplay();
  std::cout << "\nExiting.\n";

  return 0;
}
