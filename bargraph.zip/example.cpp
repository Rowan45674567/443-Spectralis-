// example.cpp
#include "ht16k33_bargraph.h"
#include <iostream>
#include <thread>

int main() {
  BarGraph24 bar;
  if (!bar.begin()) {
    std::cerr << "Failed to init HT16K33 @ 0x70\n";
    return 1;
  }

  // Light bars 0–11 green, 12–23 red
  for (uint8_t i = 0; i < 12; ++i) bar.setBar(i, BarGraph24::GREEN);
  for (uint8_t i = 12; i < 24; ++i) bar.setBar(i, BarGraph24::RED);
  bar.writeDisplay();

  std::this_thread::sleep_for(std::chrono::seconds(2));

  // Fade out by dimming
  for (int b = 15; b >= 0; --b) {
    bar.setBrightness(b);
    std::this_thread::sleep_for(std::chrono::milliseconds(200));
  }

  bar.clear();
  bar.writeDisplay();

  return 0;
}
