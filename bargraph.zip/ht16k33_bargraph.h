// ht16k33_bargraph.h
#ifndef HT16K33_BARGRAPH_H
#define HT16K33_BARGRAPH_H

#include <wiringPiI2C.h>
#include <unistd.h>
#include <array>
#include <cstdint>

class BarGraph24 {
public:
  // bicolor: OFF, RED, GREEN, YELLOW
  enum Color : uint8_t { OFF = 0, RED = 1, GREEN = 2, YELLOW = 3 };

  // addr: I2C address (AdaFruit default is 0x70)
  BarGraph24(int addr = 0x70) : _addr(addr), _fd(-1) {
    _buffer.fill(OFF);
  }

  // begin(): returns true on success
  bool begin() {
    _fd = wiringPiI2CSetup(_addr);
    if (_fd < 0) return false;
    // Turn on oscillator
    wiringPiI2CWrite(_fd, 0x21);
    // Display on, no blink
    wiringPiI2CWrite(_fd, 0x81);
    // Default brightness
    setBrightness(15);
    clear();
    writeDisplay();
    return true;
  }

  // Set global brightness [0..15]
  void setBrightness(uint8_t b) {
    if (b > 15) b = 15;
    wiringPiI2CWrite(_fd, 0xE0 | b);
  }

  // Set blink rate: 0=off,1=2Hz,2=1Hz,3=0.5Hz
  void setBlinkRate(uint8_t rate) {
    rate &= 0x03;
    wiringPiI2CWrite(_fd, 0x80 | (rate << 1) | 1);
  }

  // Set a single bar [0..23] to a Color
  void setBar(uint8_t bar, Color c) {
    if (bar >= 24) return;
    _buffer[bar] = c;
  }

  // Clear all bars
  void clear() {
    _buffer.fill(OFF);
  }

  // Push buffer -> device
  void writeDisplay() {
    // HT16K33 RAM is organized as 16 addresses of 8 bits each.
    // Our 24 bicolor LEDs are wired as 12 green + 12 red segments.
    // We'll map bar i:
    //   green → RAM addr (i/8)*2 + 0, bit (i % 8)
    //   red   → RAM addr (i/8)*2 + 1, bit (i % 8)
    uint8_t ram[16] = {0};

    for (uint8_t i = 0; i < 24; ++i) {
      uint8_t byteIndex = (i / 8) * 2;
      uint8_t bitMask   = 1 << (i % 8);
      switch (_buffer[i]) {
        case GREEN:  ram[byteIndex + 0] |= bitMask; break;
        case RED:    ram[byteIndex + 1] |= bitMask; break;
        case YELLOW: ram[byteIndex + 0] |= bitMask,
                       ram[byteIndex + 1] |= bitMask; break;
        default: break;
      }
    }

    // write out in one burst
    uint8_t payload[17];
    payload[0] = 0x00;            // start at RAM address 0
    for (int i = 0; i < 16; ++i)  payload[i+1] = ram[i];
    write(_fd, payload, 17);
  }

private:
  int       _addr, _fd;
  std::array<Color,24> _buffer;
};

#endif // HT16K33_BARGRAPH_H
